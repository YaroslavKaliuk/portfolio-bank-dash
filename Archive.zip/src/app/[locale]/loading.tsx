'use client';

import { Loader } from '@/components';

export default function Loading() {
  return <Loader />;
}
