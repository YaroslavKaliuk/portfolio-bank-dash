import '@styles/index.scss';
import { Error404 } from '../components';

export default function NotFound() {
  return <Error404 />;
}
