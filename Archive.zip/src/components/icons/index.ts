export { default as IconClose } from './iconClose';
