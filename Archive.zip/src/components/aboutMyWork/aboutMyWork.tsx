'use client';

import cn from 'classnames';
import { FC } from 'react';
import styles from './styles.module.scss';
import { Dialog } from '../dialog';
import * as Icons from '@/icons';
import { Button } from '../button';
import { useDialog } from '@/hooks';

export const AboutMyWork: FC = () => {
  const aboutMyWork = useDialog('about-my-work');

  return (
    <div className={cn(styles.aboutMyWork)}>
      <Dialog id="about-my-work">
        <div>About my work</div>
      </Dialog>
      <Button title="About My Work" iconLeft={<Icons.IconStars />} onClick={aboutMyWork.open} />
    </div>
  );
};
