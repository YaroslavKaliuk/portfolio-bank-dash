'use client';

import { FC, useEffect, useRef } from 'react';
import cn from 'classnames';
import styles from './styles.module.scss';
import * as Icons from '@/icons';

export interface DialogProps {
  id: string;
  onClose?: () => void;
  children?: React.ReactNode;
}

export const Dialog: FC<DialogProps> = ({ id, onClose, children }) => {
  const ref = useRef<HTMLDialogElement>(null);

  useEffect(() => {
    const d = ref.current;
    if (!d) return;
    const handleClick = (e: MouseEvent) => {
      if (e.target === d) {
        d.close();
        onClose?.();
      }
    };
    const handleClose = () => onClose?.();
    d.addEventListener('click', handleClick);
    d.addEventListener('close', handleClose);
    return () => {
      d.removeEventListener('click', handleClick);
      d.removeEventListener('close', handleClose);
    };
  }, [onClose]);

  return (
    <dialog id={id} ref={ref} className={cn(styles.dialog)}>
      <button type="button" className={styles.dialog__close} onClick={() => ref.current?.close()}>
        <Icons.IconClose />
      </button>
      <div className={styles.dialog__content}>{children}</div>
    </dialog>
  );
};
