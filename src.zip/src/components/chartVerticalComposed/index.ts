export * from './chartVerticalComposed';
