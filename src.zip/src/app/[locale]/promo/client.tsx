'use client';

import React from 'react';
import { useTranslations } from 'next-intl';
import { LayoutBlock, LayoutRow } from '@/layouts';
import {
  FinancialOverview,
  ServicesList,
  Button,
  Title,
  SwiperSlider,
  FormPromo,
  Accordion,
} from '@/components';
import * as Icons from '@/icons';
import Image from 'next/image';

export default function ServicesClient() {
  const t = useTranslations();
  return (
    <>
      <LayoutRow>
        <SwiperSlider
          items={[
            <Image
              key="banner2"
              src="/banner_2.jpg"
              alt="Promo"
              width={860}
              height={486}
              loading="lazy"
            />,
            <Image
              key="banner1"
              src="/banner_1.jpg"
              alt="Promo"
              width={860}
              height={486}
              loading="lazy"
            />,
          ]}
        />
      </LayoutRow>
      <LayoutRow>
        <Title title={t('titles.onlineCardApplication')} />
        <LayoutBlock>
          <FormPromo />
        </LayoutBlock>
      </LayoutRow>
      <LayoutRow isFinancialOverview>
        <LayoutBlock>
          <FinancialOverview
            icon={<Icons.IconLifeInsurance />}
            title={t('financialOverview.lifeInsurance')}
            value={t('financialOverview.unlimitedProtection')}
          />
        </LayoutBlock>
        <LayoutBlock>
          <FinancialOverview
            icon={<Icons.IconShopping />}
            title={t('financialOverview.shopping')}
            value={t('financialOverview.buyThinkGrow')}
          />
        </LayoutBlock>
        <LayoutBlock>
          <FinancialOverview
            icon={<Icons.IconSafety />}
            title={t('financialOverview.safety')}
            value={t('financialOverview.weAreYourAllies')}
          />
        </LayoutBlock>
      </LayoutRow>
      <LayoutRow isGridColumnFull>
        <Title title={t('titles.bankServicesList')} />
        <ServicesList
          rows={[
            [
              { icon: <Icons.IconExpense /> },
              {
                title: t('services.checkingAccounts.title'),
                value: t('services.checkingAccounts.value'),
              },
              {
                title: t('services.checkingAccounts.noFees'),
                value: t('services.checkingAccounts.noFeesValue'),
              },
              {
                title: t('services.checkingAccounts.access'),
                value: t('services.checkingAccounts.accessValue'),
              },
              {
                title: t('services.checkingAccounts.security'),
                value: t('services.checkingAccounts.securityValue'),
              },
              { button: <Button title={t('services.checkingAccounts.button')} isOutline /> },
            ],
            [
              { icon: <Icons.IconSaving /> },
              {
                title: t('services.savingsAccounts.title'),
                value: t('services.savingsAccounts.value'),
              },
              {
                title: t('services.savingsAccounts.interest'),
                value: t('services.savingsAccounts.interestValue'),
              },
              {
                title: t('services.savingsAccounts.withdrawals'),
                value: t('services.savingsAccounts.withdrawalsValue'),
              },
              {
                title: t('services.savingsAccounts.fees'),
                value: t('services.savingsAccounts.feesValue'),
              },
              { button: <Button title={t('services.savingsAccounts.button')} isOutline /> },
            ],
            [
              { icon: <Icons.IconLoan /> },
              {
                title: t('services.businessLoans.title'),
                value: t('services.businessLoans.value'),
              },
              {
                title: t('services.businessLoans.rates'),
                value: t('services.businessLoans.ratesValue'),
              },
              {
                title: t('services.businessLoans.approval'),
                value: t('services.businessLoans.approvalValue'),
              },
              {
                title: t('services.businessLoans.solutions'),
                value: t('services.businessLoans.solutionsValue'),
              },
              { button: <Button title={t('services.businessLoans.button')} isOutline /> },
            ],
            [
              { icon: <Icons.IconCreditCard /> },
              {
                title: t('services.debitCreditCards.title'),
                value: t('services.debitCreditCards.value'),
              },
              {
                title: t('services.debitCreditCards.cashback'),
                value: t('services.debitCreditCards.cashbackValue'),
              },
              {
                title: t('services.debitCreditCards.global'),
                value: t('services.debitCreditCards.globalValue'),
              },
              {
                title: t('services.debitCreditCards.protection'),
                value: t('services.debitCreditCards.protectionValue'),
              },
              { button: <Button title={t('services.debitCreditCards.button')} isOutline /> },
            ],
            [
              { icon: <Icons.IconSafety /> },
              {
                title: t('services.lifeInsurance.title'),
                value: t('services.lifeInsurance.value'),
              },
              {
                title: t('services.lifeInsurance.plans'),
                value: t('services.lifeInsurance.plansValue'),
              },
              {
                title: t('services.lifeInsurance.premiums'),
                value: t('services.lifeInsurance.premiumsValue'),
              },
              {
                title: t('services.lifeInsurance.protection'),
                value: t('services.lifeInsurance.protectionValue'),
              },
              { button: <Button title={t('services.lifeInsurance.button')} isOutline /> },
            ],
          ]}
        />
      </LayoutRow>
      <LayoutRow isGridColumnFull>
        <Title title={t('titles.bankPromotionsSpecialOffers')} />
        <LayoutBlock>
          <Accordion
            items={[
              {
                title: 'Exclusive Credit Card Offers',
                content:
                  'Get our premium credit card with 0% APR for the first 12 months and earn 3% cashback on all purchases. Limited time offer!',
              },
              {
                title: 'Mortgage Rate Special',
                content:
                  'Lock in our lowest-ever mortgage rates at 3.25% APR for 30-year fixed loans. Apply before December 31st to qualify.',
              },
              {
                title: 'New Customer Bonus',
                content:
                  'Open a new checking account with $500 minimum deposit and receive a $300 welcome bonus. Terms and conditions apply.',
              },
              {
                title: 'Business Banking Solutions',
                content:
                  'Special business accounts with no monthly fees for the first year. Includes free transactions and dedicated account manager.',
              },
              {
                title: 'Wealth Management Promo',
                content:
                  'Free financial planning consultation for deposits over $50,000. Grow your wealth with our expert advisors.',
              },
            ]}
          />
        </LayoutBlock>
      </LayoutRow>
    </>
  );
}
